package com.dentech;

public class StudentTwo {
    int registrationNumber;
    String name;
    int age;
    StudentTwo(int registrationNumber,String name,int age){
        this.registrationNumber=registrationNumber;
        this.name=name;
        this.age=age;
    }
}
