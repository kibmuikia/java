package StoreApplication;

public class Category implements java.io.Serializable{
    String category;

    public Category(String category) {
        this.category = category;
    }
}
