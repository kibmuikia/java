-What do I have?
-How much have I sold?
-How much Profit?
-When do I order?
-How much sales per user?

DESIGN
-Add Product
-List Product
-size of stock
-Products per user
-Reports

Classes
-Customer
-Item/Category
-Order
-User
-Receipt 