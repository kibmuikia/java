package Databases;

public class DatabasesMainClass {
    public static void main(String[] args) {
        DatabaseConnection dbconnection = new DatabaseConnection();
        dbconnection.sqlOperator();
    }
}
